var files_dup =
[
    [ "Core.cpp", "_core_8cpp.html", null ],
    [ "Core.h", "_core_8h.html", [
      [ "Core", "class_core.html", "class_core" ]
    ] ],
    [ "CoreAdapter.cpp", "_core_adapter_8cpp.html", null ],
    [ "CoreAdapter.h", "_core_adapter_8h.html", [
      [ "CoreAdapter", "class_core_adapter.html", "class_core_adapter" ]
    ] ],
    [ "Falcon.cpp", "_falcon_8cpp.html", null ],
    [ "Falcon.h", "_falcon_8h.html", [
      [ "Falcon", "class_falcon.html", "class_falcon" ]
    ] ],
    [ "Falcon9.cpp", "_falcon9_8cpp.html", null ],
    [ "Falcon9.h", "_falcon9_8h.html", [
      [ "Falcon9", "class_falcon9.html", "class_falcon9" ]
    ] ],
    [ "FalconHeavy.cpp", "_falcon_heavy_8cpp.html", null ],
    [ "FalconHeavy.h", "_falcon_heavy_8h.html", [
      [ "FalconHeavy", "class_falcon_heavy.html", "class_falcon_heavy" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "MerlinRocket.cpp", "_merlin_rocket_8cpp.html", null ],
    [ "MerlinRocket.h", "_merlin_rocket_8h.html", [
      [ "MerlinRocket", "class_merlin_rocket.html", "class_merlin_rocket" ]
    ] ],
    [ "MerlinVac.cpp", "_merlin_vac_8cpp.html", null ],
    [ "MerlinVac.h", "_merlin_vac_8h.html", [
      [ "MerlinVac", "class_merlin_vac.html", "class_merlin_vac" ]
    ] ],
    [ "Stage.cpp", "_stage_8cpp.html", null ],
    [ "Stage.h", "_stage_8h.html", [
      [ "Stage", "class_stage.html", "class_stage" ]
    ] ],
    [ "StageOne.cpp", "_stage_one_8cpp.html", null ],
    [ "StageOne.h", "_stage_one_8h.html", [
      [ "StageOne", "class_stage_one.html", "class_stage_one" ]
    ] ],
    [ "StageTwo.cpp", "_stage_two_8cpp.html", null ],
    [ "StageTwo.h", "_stage_two_8h.html", [
      [ "StageTwo", "class_stage_two.html", "class_stage_two" ]
    ] ]
];