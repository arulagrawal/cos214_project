var class_stage =
[
    [ "Stage", "class_stage.html#a6df4ef2a9646da0e6c945945c9d764ee", null ],
    [ "boost", "class_stage.html#af43af8bc409225909496922ddaa9bc7d", null ],
    [ "next", "class_stage.html#a4182f27f0f14941bd435ec3b4f270613", null ],
    [ "off", "class_stage.html#a6a8cde729c1f1e5d142a7f9511f5c38f", null ],
    [ "on", "class_stage.html#aa2c536368a830b65f03c2dc1bae9d402", null ],
    [ "staticFire", "class_stage.html#a8d305108ada4ac180e56214a7843c1a7", null ],
    [ "StageOne", "class_stage.html#a8a97b6d5e408db103798551949a4e1f8", null ],
    [ "StageTwo", "class_stage.html#a31edb70a2ee8eb471bca59692390954c", null ]
];