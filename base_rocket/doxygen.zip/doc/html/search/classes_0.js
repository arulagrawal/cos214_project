var searchData=
[
  ['core_0',['Core',['../class_core.html',1,'']]],
  ['coreadapter_1',['CoreAdapter',['../class_core_adapter.html',1,'']]]
];
