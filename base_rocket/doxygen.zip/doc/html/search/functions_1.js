var searchData=
[
  ['core_0',['Core',['../class_core.html#a42a44e91db4fc21b333e090d2648f414',1,'Core']]],
  ['coreadapter_1',['CoreAdapter',['../class_core_adapter.html#ad8efc0d500a0ef954a01f2de869c37f8',1,'CoreAdapter']]]
];
