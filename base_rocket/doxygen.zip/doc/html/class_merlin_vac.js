var class_merlin_vac =
[
    [ "MerlinVac", "class_merlin_vac.html#a10156856cafdea4ae0b5a5199e90be29", null ],
    [ "boost", "class_merlin_vac.html#a83476ed2f499b7f4e44c5c3a6a758075", null ],
    [ "hasFuel", "class_merlin_vac.html#a355e65a4d0030fe5122c0e46d4444ca9", null ],
    [ "isOn", "class_merlin_vac.html#a60ca739559e1319706f5a7400fb98dde", null ],
    [ "off", "class_merlin_vac.html#a970ec6c5ecad752dc021892a523180b1", null ],
    [ "on", "class_merlin_vac.html#a5a87dee6b3654d5ab1ef4590c1e5fad0", null ],
    [ "test", "class_merlin_vac.html#aafe0c037d814e913a444b5dabd66654e", null ]
];