var class_core_adapter =
[
    [ "CoreAdapter", "class_core_adapter.html#ad8efc0d500a0ef954a01f2de869c37f8", null ],
    [ "boost", "class_core_adapter.html#a28434fb63f9825eec2b3c10e62f160bf", null ],
    [ "getFuelWeight", "class_core_adapter.html#a6b32e3d019a72261afbbfbf962655d28", null ],
    [ "hasFuel", "class_core_adapter.html#a0a7f6d3a43bdb740609c9b1e46243ec3", null ],
    [ "isOn", "class_core_adapter.html#a8c22d3c157a843467c75c29fc877e06c", null ],
    [ "off", "class_core_adapter.html#a3279fccb998c9d13dd7aa2e38afe5cfe", null ],
    [ "on", "class_core_adapter.html#afa3c3a8ba14e3c35a001d2ed46aa540e", null ],
    [ "staticFire", "class_core_adapter.html#a3d074dec770e684675bab3d61728d549", null ]
];