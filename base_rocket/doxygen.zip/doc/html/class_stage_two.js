var class_stage_two =
[
    [ "StageTwo", "class_stage_two.html#a9270c02720753c3aa60ed0c4533952d1", null ],
    [ "boost", "class_stage_two.html#ae9b1e891c5d6f2afcf20d397e54e6edb", null ],
    [ "getStage", "class_stage_two.html#a2d628f65a24c7621d15947d76031b2bf", null ],
    [ "next", "class_stage_two.html#a9db16efe3a7c9048903f772d7bba8663", null ],
    [ "off", "class_stage_two.html#a0d4e0b082fefd6f1be418eb1624a0501", null ],
    [ "on", "class_stage_two.html#a054cae87d39304e5553be3ecc02c10fc", null ],
    [ "staticFire", "class_stage_two.html#a13e00e67ff6fb177988147d0d38240f8", null ]
];